import bluetooth
import re

def bluetooth_connect():
    server_sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )
    port = 1
    server_sock.bind(("",port))
    server_sock.listen(1)

    client_sock, address = server_sock.accept()
    print("Accepted connection from ",address)

    try:
        while True:
            data = client_sock.recv(1024)
            data = data.decode('utf-8')
            data = data.replace("\n", "")
            tmp = []
            tmp = data.split(',')
            uid = tmp[0]
            sub = tmp[1]
            if(data):
                print("success!")
                print("%s" % data)
                return uid, sub
            else:
                print("no data!")
                continue
    except:
        print("except: ", address)
    finally:
        client_sock.close()
        server_sock.close()

    client_sock.close()
    server_sock.close()