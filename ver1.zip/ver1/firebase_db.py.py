#-*-coding:utf-8 -*-
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import datetime as dt

def db_update(login_uid, sub):
    cred = credentials.Certificate("./ServiceAccountKey.json")
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    day = dt.datetime.now()
    date = day.strftime('%m.%d')

    doc_ref = db.collection(u'users').document(login_uid).collection(u'database').document(sub).collection(u'2021').document(date)
    doc_ref.update({
        u'attendance' : True,
        u'time' : day
    })

    try:
        doc = doc_ref.get()
        print(u'Document data: {}'.format(doc.to_dict()))
    except google.cloud.exceptions.NotFound:
        print(u'No such document!')
