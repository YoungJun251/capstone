import bluetooth
import re #Regular Expression
import cv2
import numpy as np
import os
import time
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import datetime as dt
import bluetooth_connect as bc
import faceRecognition as fR
import firebase_db as db

uid, sub = bc.bluetooth_connect()
login_uid = fR.faceRec(uid)
db.db_update(login_uid, sub)